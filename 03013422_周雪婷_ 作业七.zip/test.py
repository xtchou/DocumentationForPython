import unittest
import IF97

class testCase(unittest.TestCase):
    def test_specific_volume(self):
        self.assertEqual(IF97.specific_volume(3, 300),0.000886080361007225)
    def test_specific_enthalpy(self):
        self.assertEqual(IF97.specific_enthalpy(3, 300),267.92906797930164)
    def test_specific_internal_energy(self):
        self.assertEqual(IF97.specific_internal_energy(3, 300),265.27082689627997)
    def test_specific_entropy(self):
        self.assertEqual(IF97.specific_entropy(3, 300),0.9938614515869214)
    def test_specific_isobaric_heat_capacity(self):
        self.assertEqual(IF97.specific_isobaric_heat_capacity(3, 300),4.184055796861844)
    def test_speed_of_sound(self):
        self.assertEqual(IF97.speed_of_sound(3, 300),1454.4345713353068)

if __name__ == '__main__':
    unittest.main()
